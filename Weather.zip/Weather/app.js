"use strict";
console.log("This is console.log Hello")
var skycons = new Skycons({ color: "white" });
// on Android, a nasty hack is needed: {"resizeClear": true}

// you can add a canvas by it's ID...
skycons.add("icon1", Skycons.SNOW);

// ...or by the canvas DOM element itself.
skycons.add(document.getElementById("icon2"), Skycons.RAIN);

// if you're using the Forecast API, you can also supply
// strings: "partly-cloudy-day" or "rain".

// start animation!
skycons.play();

// you can also halt animation with skycons.pause()

// want to change the icon? no problem:
// skycons.set("icon1", Skycons.PARTLY_CLOUDY_NIGHT);

// want to remove one altogether? no problem:
// skycons.remove("icon2");

const api = {
    key: "9e2ecab5b6e6157d86b23ff51e1b4fcd",
    base: "https://api.openweathermap.org/data/2.5/"
}

const searchbox = document.querySelector('.search-box');
searchbox.addEventListener('keypress', setQuery);

function setQuery(evt) {
    if (evt.keyCode == 13) {
        getResult(searchbox.value);
        console.log(searchbox.value);
    }
}

function getResult(query) {
    fetch(`${api.base}weather?q=${query}&units=metric&APPID=${api.key}`)
        .then(weather => {
            return weather.json();
        }).then(displayResults);
}

function displayResults (weather) {
    console.log(weather);

    switch (weather.weather[0].main) {
        case 'Clear':
            document.body.style.backgroundImage = 'url("Clear.jpg")';
            break;
        
        case 'Clouds':
            document.body.style.backgroundImage = 'url("Cloudy.jpg")';
            break;
        
        case 'Rain':
        case 'Drizzle':
        case 'Mist':
            document.body.style.backgroundImage = 'url("Rain.jpg")';
            break;
        
        case 'Thunderstorm':
            document.body.style.backgroundImage = 'url("Storm.jpg")';
            break;
        
        case 'Snow':
            document.body.style.backgroundImage = 'url("Snow.jpg")';
            break;
    
        default:
            break;
    }

    let city = document.querySelector('.location .city');
    city.innerText = `${weather.name}, ${weather.sys.country}`;

    let now = new Date();
    let date = document.querySelector('.location .date');
    date.innerText = dateBuilder(now);

    let temp = document.querySelector('.current .temp');
    temp.innerHTML = `${Math.round(weather.main.temp)}°C`;
    
    let weather_el = document.querySelector('.current .weather');
    weather_el.innerText = weather.weather[0].description;

    var iconcode = weather.weather[0].icon;
    var iconurl = "http://openweathermap.org/img/wn/" +
        iconcode +
        "@2x.png";
    let icons = document.querySelector('.icons');
    icons.src = iconurl;

    let hilow = document.querySelector('.hi-low');
    hilow.innerText = `${Math.round(weather.main.temp_max)}°C / ${Math.round(weather.main.temp_min)}°C`;
}

function dateBuilder(d) {
    let months = ["January", "February", "March", "April",
        "May", "June", "July", "August",
        "September", "October", "November", "December"];
    let days = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];

    let day = days[d.getDay()];
    let date = d.getDate();
    let month = months[d.getMonth()];
    let year = d.getFullYear();

    return `${day} ${date} ${month} ${year}`;
}













